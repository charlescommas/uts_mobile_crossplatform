export interface Product{
    id: string;
    category: string;
    image: string;
    name: string;
    price: number;
    stock: number;
}